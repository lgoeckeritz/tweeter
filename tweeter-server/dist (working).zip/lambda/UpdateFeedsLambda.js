"use strict";
/**
 *  gets the following from the UpdateFeedQueue:
 * - the status being posted
 * - who is the user that posted it
 * - 25 aliases (from the list of followers)
 *
 * just needs to update the feed for the list of aliases
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const StatusService_1 = require("../model/service/StatusService");
const DDBDAOFactory_1 = require("../model/dao/DynamoDB/DDBDAOFactory");
const handler = function (event) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < event.Records.length; ++i) {
            const { body } = event.Records[i];
            const dataReviver = (key, value) => {
                if (key === "Status") {
                    return tweeter_shared_1.Status.fromJson(value);
                }
                else {
                    return value;
                }
            };
            const request = JSON.parse(body, dataReviver);
            if (request === undefined) {
                throw new Error("[Server Error] couldn't parse request in updateFeeds Lambda");
            }
            const followerHandles = request.Followers;
            const status = request.Status;
            yield new StatusService_1.StatusService(new DDBDAOFactory_1.DDBDAOFactory()).postToFeeds(followerHandles, status);
        }
    });
};
exports.handler = handler;
