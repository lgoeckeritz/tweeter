"use strict";
/**
 * should receive from the PostStatusQueue:
 * who posted and the actual status
 *
 * then:
 * find out how many followers there are
 * writes to the UpdateFeedQueue with the following:
 * - the status being posted
 * - who is the user that posted it
 * - 25 aliases (from the list of followers)
 *   ** note that 25 isn't the end all be all, it might need to be changed **
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const DDBDAOFactory_1 = require("../model/dao/DynamoDB/DDBDAOFactory");
const StatusService_1 = require("../model/service/StatusService");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const BATCH_SIZE = 100;
const handler = function (event) {
    return __awaiter(this, void 0, void 0, function* () {
        for (let i = 0; i < event.Records.length; ++i) {
            const { body } = event.Records[i];
            const status = tweeter_shared_1.Status.fromJson(body);
            if (status === null) {
                throw new Error("[Server Error] could not deserialize status from PostStatusQueue");
            }
            const userHandle = status.user.alias;
            //getting list of followers
            const followers = yield new StatusService_1.StatusService(new DDBDAOFactory_1.DDBDAOFactory()).getFollowers(userHandle);
            //splitting up list into groups of 100 to send to the UpdateFeedQueue
            let sqsClient = new client_sqs_1.SQSClient();
            const sqs_url = "https://sqs.us-east-1.amazonaws.com/036298631532/UpdateFeedQueue";
            for (let i = 0; i < followers.length; i += BATCH_SIZE) {
                const messageBody = JSON.stringify({
                    Followers: followers.slice(i, i + BATCH_SIZE),
                    Status: body,
                });
                const params = {
                    MessageBody: messageBody,
                    QueueUrl: sqs_url,
                };
                try {
                    const data = yield sqsClient.send(new client_sqs_1.SendMessageCommand(params));
                    console.log("Success, batch ", i, " sent. MessageID:", data.MessageId);
                }
                catch (err) {
                    throw new Error("[Server Error] couldn't post status to followers feed do to: " +
                        err);
                }
            }
        }
        return null;
    });
};
exports.handler = handler;
