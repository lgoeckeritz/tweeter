"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBDAO = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const DataPage_1 = require("../../entity/DataPage");
class DDBDAO {
    constructor(tableName, client) {
        this.tableName = tableName;
        this.client = client;
    }
    //might not be needed?
    // async recordItem(entity: T): Promise<void> {
    //     //load if it doesn't exist
    //     const itemInDatabase: T | undefined = await this.getItem(entity);
    //     if (itemInDatabase !== undefined) {
    //         console.log(
    //             "This item is already in the ",
    //             this.tableName,
    //             "table, updating values of existing item"
    //         );
    //         await this.updateItem(entity);
    //     } else {
    //         await this.putItem(entity);
    //     }
    // }
    putItem(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Item: this.generatePutItem(entity),
            };
            yield this.client.send(new lib_dynamodb_1.PutCommand(params));
        });
    }
    updateItem(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateGetItem(entity),
                UpdateExpression: this.getUpdateExpression(),
                ExpressionAttributeValues: this.getUpdateExpressionAttributeValues(entity),
            };
            yield this.client.send(new lib_dynamodb_1.UpdateCommand(params));
        });
    }
    getItem(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateGetItem(entity),
            };
            const output = yield this.client.send(new lib_dynamodb_1.GetCommand(params));
            return output.Item == undefined
                ? undefined
                : this.newEntity(output.Item);
        });
    }
    deleteItem(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateGetItem(entity),
            };
            yield this.client.send(new lib_dynamodb_1.DeleteCommand(params));
        });
    }
    getPageOfItems(params) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const items = [];
            const data = yield this.client.send(new lib_dynamodb_1.QueryCommand(params));
            const hasMorePages = data.LastEvaluatedKey !== undefined;
            (_a = data.Items) === null || _a === void 0 ? void 0 : _a.forEach((item) => items.push(this.newEntity(item)));
            return new DataPage_1.DataPage(items, hasMorePages);
        });
    }
}
exports.DDBDAO = DDBDAO;
