"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBUsersDAO = void 0;
const UserEntity_1 = require("../../entity/UserEntity");
const DDBDAO_1 = require("./DDBDAO");
class DDBUsersDAO extends DDBDAO_1.DDBDAO {
    constructor() {
        super("users");
        this.first_name = "first_name";
        this.last_name = "last_name";
        this.handle = "handle";
        this.image_url = "image_url";
        this.password = "password";
        this.num_followers = "num_followers";
        this.num_followees = "num_followees";
        this.saltRounds = 8;
    }
    newEntity(output) {
        return new UserEntity_1.UserEntity(output.Item[this.first_name], output.Item[this.last_name], output.Item[this.handle], output.Item[this.image_url], output.Item[this.password], output.Item[this.num_followers], output.Item[this.num_followees]);
    }
    generateGetItem(entity) {
        return {
            [this.handle]: entity.alias,
        };
    }
    generatePutItem(entity) {
        return {
            [this.handle]: entity.alias,
            [this.first_name]: entity.firstName,
            [this.last_name]: entity.lastName,
            [this.image_url]: entity.imageUrl,
            [this.password]: entity.password,
            [this.num_followers]: entity.numFollowers,
            [this.num_followees]: entity.numFollowees,
        };
    }
    getUpdateExpression() {
        return "set num_followers = :value1, num_followees = :value2";
    }
    getUpdateExpressionAttributeValues(entity) {
        return {
            ":value1": entity.numFollowers,
            ":value2": entity.numFollowees,
        };
    }
    loginUser(alias, password) {
        return __awaiter(this, void 0, void 0, function* () {
            //getting user associated with the alias
            const userEntity = yield this.getUser(alias);
            if (userEntity === undefined) {
                return undefined;
            }
            //comparing the passwords to make sure they match
            const bcrypt = require("bcryptjs");
            yield bcrypt.compare(password, userEntity.password, function (err, res) {
                if (res) {
                    return userEntity;
                }
                else {
                    return undefined;
                }
            });
        });
    }
    registerUser(firstName, lastName, alias, password, imageUrl) {
        return __awaiter(this, void 0, void 0, function* () {
            //hashing the password
            let hashPassword = "";
            const bcrypt = require("bcryptjs");
            bcrypt.hash(password, this.saltRounds, function (err, hash) {
                if (err) {
                    return undefined;
                }
                else {
                    hashPassword = hash;
                }
            });
            const newUserEntity = new UserEntity_1.UserEntity(firstName, lastName, alias, imageUrl, hashPassword, 0, 0);
            //putting new user into the table
            yield this.putItem(newUserEntity);
            return newUserEntity;
        });
    }
    getUser(userHandle) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.getItem(new UserEntity_1.UserEntity("", "", userHandle, "", "", 0, 0));
        });
    }
}
exports.DDBUsersDAO = DDBUsersDAO;
