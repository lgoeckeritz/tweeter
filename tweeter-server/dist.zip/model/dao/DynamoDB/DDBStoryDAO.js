"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBStoryDAO = void 0;
const DataPage_1 = require("../../entity/DataPage");
const StatusEntity_1 = require("../../entity/StatusEntity");
const DDBDAO_1 = require("./DDBDAO");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class DDBStoryDAO extends DDBDAO_1.DDBDAO {
    constructor() {
        super("story");
        this.author_handle = "author_handle";
        this.time_stamp = "time_stamp";
        this.status_json = "status_json";
    }
    newEntity(output) {
        return new StatusEntity_1.StatusEntity(output.Item[this.author_handle], output.Item[this.time_stamp], output.Item[this.status_json]);
    }
    generateGetItem(entity) {
        return {
            [this.author_handle]: entity.handle,
            [this.time_stamp]: entity.time_stamp,
        };
    }
    generatePutItem(entity) {
        return {
            [this.author_handle]: entity.handle,
            [this.time_stamp]: entity.time_stamp,
            [this.status_json]: entity.statusJson,
        };
    }
    //not being used so not implimented
    getUpdateExpression() {
        throw new Error("Method not implemented.");
    }
    //not being used so not implimented
    getUpdateExpressionAttributeValues(entity) {
        throw new Error("Method not implemented.");
    }
    recordStory(statusEntity) {
        return __awaiter(this, void 0, void 0, function* () {
            this.putItem(statusEntity);
        });
    }
    getStory(user, pageSize, lastItem) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                KeyConditionExpression: this.author_handle + " = :v",
                ExpressionAttributeValues: {
                    ":v": user.alias,
                },
                TableName: this.tableName,
                Limit: pageSize,
                ExclusiveStartKey: lastItem === null
                    ? undefined
                    : {
                        [this.author_handle]: user.alias,
                        [this.status_json]: lastItem.toJson,
                    },
            };
            const items = [];
            const data = yield this.client.send(new lib_dynamodb_1.QueryCommand(params));
            const hasMorePages = data.LastEvaluatedKey !== undefined;
            (_a = data.Items) === null || _a === void 0 ? void 0 : _a.forEach((item) => items.push(new StatusEntity_1.StatusEntity(item[this.author_handle], item[this.time_stamp], item[this.status_json])));
            return new DataPage_1.DataPage(items, hasMorePages);
        });
    }
}
exports.DDBStoryDAO = DDBStoryDAO;
