"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBAuthTokenDAO = void 0;
const AuthTokenEntity_1 = require("../../entity/AuthTokenEntity");
const DDBDAO_1 = require("./DDBDAO");
class DDBAuthTokenDAO extends DDBDAO_1.DDBDAO {
    constructor(client) {
        super("authtokens", client);
        this.token = "token";
        this.time_stamp = "time_stamp";
        this.user_handle = "user_handle";
        this.expirationTime = 10;
    }
    generateGetItem(authtoken) {
        return {
            [this.token]: authtoken.token,
        };
    }
    newEntity(item) {
        return new AuthTokenEntity_1.AuthTokenEntity(item[this.token], item[this.time_stamp], item[this.user_handle]);
    }
    generatePutItem(entity) {
        return {
            [this.token]: entity.token,
            [this.time_stamp]: entity.time_stamp,
            [this.user_handle]: entity.userHandle,
        };
    }
    getUpdateExpression() {
        return "set time_stamp = :value1";
    }
    getUpdateExpressionAttributeValues(entity) {
        return {
            ":value1": entity.time_stamp,
        };
    }
    /**
     * Checks to see if the authtoken provided is currently in the database
     * and not timed out. If it is and not timed out, the time_stamp is updated
     * to the current time and this returns true
     * @param token is the authToken that should be in the database
     */
    authenticate(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const currentToken = new AuthTokenEntity_1.AuthTokenEntity(token, Date.now(), "unknown");
            const oldToken = yield this.getItem(currentToken);
            if (oldToken !== undefined) {
                //Calculate the difference in minutes
                let differenceInMinutes = Math.abs(currentToken.time_stamp - oldToken.time_stamp) /
                    1000 /
                    60;
                if (differenceInMinutes <= this.expirationTime) {
                    //now that the authtoken is valid, the time_stamp needs to be updated
                    currentToken.userHandle = oldToken.userHandle;
                    yield this.updateItem(currentToken);
                    return true;
                }
                else {
                    //deletes the timed out authtoken
                    this.deleteAuthToken(token);
                    return false;
                }
            }
            else {
                return false;
            }
        });
    }
    /**
     * This lets us find the userhandle that's associated with an authtoken
     * @param token is associated with the handle of the user we're trying to find
     */
    getAuthTokenHandle(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const foundToken = yield this.getItem(new AuthTokenEntity_1.AuthTokenEntity(token, 0, "unknown"));
            if (foundToken === undefined) {
                throw new Error("[Forbidden Error] invalid authtoken");
            }
            return foundToken.userHandle;
        });
    }
    /**
     * This stores a new authtoken in the table when someone logs in or registers
     * @param authTokenEntity new authtoken to store in the table
     */
    recordAuthToken(authTokenEntity) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.putItem(authTokenEntity);
        });
    }
    /**
     * Removes token from table, usually when found to be timed out
     * or when the user is logging out. Not essential but it keeps the
     * tables from filling up.
     * @param token token to be removed
     */
    deleteAuthToken(token) {
        return __awaiter(this, void 0, void 0, function* () {
            this.deleteItem(new AuthTokenEntity_1.AuthTokenEntity(token, 0, "unknown"));
        });
    }
}
exports.DDBAuthTokenDAO = DDBAuthTokenDAO;
