"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBFollowsDAO = void 0;
const FollowEntity_1 = require("../../entity/FollowEntity");
const DDBDAO_1 = require("./DDBDAO");
class DDBFollowsDAO extends DDBDAO_1.DDBDAO {
    constructor(client) {
        super("follows", client);
        this.indexName = "follows_index";
        this.followerHandle = "follower_handle";
        this.followeeHandle = "followee_handle";
        this.followerName = "follower_name";
        this.followeeName = "followee_name";
    }
    putFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.putItem(follow);
        });
    }
    updateNames(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.updateItem(follow);
        });
    }
    getFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.getItem(follow);
        });
    }
    deleteFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.deleteItem(follow);
        });
    }
    getPageOfFollowees(followerHandle, pageSize, lastFolloweeHandle = undefined) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.getPageOfItems({
                KeyConditionExpression: this.followerHandle + " = :v",
                ExpressionAttributeValues: {
                    ":v": followerHandle,
                },
                TableName: this.tableName,
                Limit: pageSize,
                ExclusiveStartKey: lastFolloweeHandle === undefined
                    ? undefined
                    : {
                        [this.followerHandle]: followerHandle,
                        [this.followeeHandle]: lastFolloweeHandle,
                    },
            });
        });
    }
    getPageOfFollowers(followeeHandle, pageSize, lastFollowerHandle = undefined) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.getPageOfItems({
                KeyConditionExpression: this.followeeHandle + " = :v",
                ExpressionAttributeValues: {
                    ":v": followeeHandle,
                },
                TableName: this.tableName,
                IndexName: this.indexName,
                Limit: pageSize,
                ExclusiveStartKey: lastFollowerHandle === undefined
                    ? undefined
                    : {
                        [this.followeeHandle]: followeeHandle,
                        [this.followerHandle]: lastFollowerHandle,
                    },
            });
        });
    }
    newEntity(item) {
        return new FollowEntity_1.FollowEntity(item[this.followerHandle], item[this.followerName], item[this.followeeHandle], item[this.followeeName]);
    }
    generateGetItem(entity) {
        return {
            [this.followerHandle]: entity.followerHandle,
            [this.followeeHandle]: entity.followeeHandle,
        };
    }
    generatePutItem(entity) {
        return {
            [this.followerHandle]: entity.followerHandle,
            [this.followerName]: entity.followerName,
            [this.followeeHandle]: entity.followeeHandle,
            [this.followeeName]: entity.followeeName,
        };
    }
    getUpdateExpression() {
        return "set follower_name = :value1, followee_name = :value2";
    }
    getUpdateExpressionAttributeValues(entity) {
        return {
            ":value1": entity.followerName,
            ":value2": entity.followeeName,
        };
    }
}
exports.DDBFollowsDAO = DDBFollowsDAO;
