"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBFollowsDAO = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const FollowEntity_1 = require("../../entity/FollowEntity");
const DataPage_1 = require("../../entity/DataPage");
class DDBFollowsDAO {
    constructor() {
        this.tableName = "follows";
        this.indexName = "follows_index";
        this.followerHandle = "follower_handle";
        this.followeeHandle = "followee_handle";
        this.followerName = "follower_name";
        this.followeeName = "followee_name";
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient());
    }
    getRelationship(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateFollowItem(follow),
            };
            const output = yield this.client.send(new lib_dynamodb_1.GetCommand(params));
            if (output.Item === undefined) {
                return 0;
            }
            else {
                return [
                    output.Item[this.followerHandle],
                    output.Item[this.followerName],
                    output.Item[this.followeeHandle],
                    output.Item[this.followeeName],
                ];
            }
        });
    }
    recordFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            //load if it doesn't exist
            const followInDatabase = yield this.getFollow(follow);
            if (followInDatabase !== undefined) {
                console.log("This relationship is already in the database, updating names");
                yield this.updateNames(follow);
            }
            else {
                yield this.putFollow(follow);
            }
        });
    }
    putFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Item: {
                    [this.followerHandle]: follow.followerHandle,
                    [this.followerName]: follow.followerName,
                    [this.followeeHandle]: follow.followeeHandle,
                    [this.followeeName]: follow.followeeName,
                },
            };
            yield this.client.send(new lib_dynamodb_1.PutCommand(params));
        });
    }
    updateNames(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateFollowItem(follow),
                UpdateExpression: "set follower_name = :value1, followee_name = :value2",
                ExpressionAttributeValues: {
                    ":value1": follow.followerName,
                    ":value2": follow.followeeName,
                },
            };
            yield this.client.send(new lib_dynamodb_1.UpdateCommand(params));
        });
    }
    getFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateFollowItem(follow),
            };
            const output = yield this.client.send(new lib_dynamodb_1.GetCommand(params));
            return output.Item == undefined
                ? undefined
                : new FollowEntity_1.FollowEntity(output.Item[this.followerHandle], output.Item[this.followerName], output.Item[this.followeeHandle], output.Item[this.followeeName]);
        });
    }
    deleteFollow(follow) {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: this.tableName,
                Key: this.generateFollowItem(follow),
            };
            yield this.client.send(new lib_dynamodb_1.DeleteCommand(params));
        });
    }
    generateFollowItem(follow) {
        return {
            [this.followerHandle]: follow.followerHandle,
            [this.followeeHandle]: follow.followeeHandle,
        };
    }
    getPageOfFollowees(followerHandle, pageSize, lastFolloweeHandle = undefined) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                KeyConditionExpression: this.followerHandle + " = :v",
                ExpressionAttributeValues: {
                    ":v": followerHandle,
                },
                TableName: this.tableName,
                Limit: pageSize,
                ExclusiveStartKey: lastFolloweeHandle === undefined
                    ? undefined
                    : {
                        [this.followerHandle]: followerHandle,
                        [this.followeeHandle]: lastFolloweeHandle,
                    },
            };
            const items = [];
            const data = yield this.client.send(new lib_dynamodb_1.QueryCommand(params));
            const hasMorePages = data.LastEvaluatedKey !== undefined;
            (_a = data.Items) === null || _a === void 0 ? void 0 : _a.forEach((item) => items.push(new FollowEntity_1.FollowEntity(item[this.followerHandle], item[this.followerName], item[this.followeeHandle], item[this.followeeName])));
            return new DataPage_1.DataPage(items, hasMorePages);
        });
    }
    getPageOfFollowers(followeeHandle, pageSize, lastFollowerHandle = undefined) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                KeyConditionExpression: this.followeeHandle + " = :v",
                ExpressionAttributeValues: {
                    ":v": followeeHandle,
                },
                TableName: this.tableName,
                IndexName: this.indexName,
                Limit: pageSize,
                ExclusiveStartKey: lastFollowerHandle === undefined
                    ? undefined
                    : {
                        [this.followeeHandle]: followeeHandle,
                        [this.followerHandle]: lastFollowerHandle,
                    },
            };
            const items = [];
            const data = yield this.client.send(new lib_dynamodb_1.QueryCommand(params));
            const hasMorePages = data.LastEvaluatedKey !== undefined;
            (_a = data.Items) === null || _a === void 0 ? void 0 : _a.forEach((item) => items.push(new FollowEntity_1.FollowEntity(item[this.followerHandle], item[this.followerName], item[this.followeeHandle], item[this.followeeName])));
            return new DataPage_1.DataPage(items, hasMorePages);
        });
    }
}
exports.DDBFollowsDAO = DDBFollowsDAO;
