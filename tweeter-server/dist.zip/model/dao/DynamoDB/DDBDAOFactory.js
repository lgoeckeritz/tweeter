"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBDAOFactory = void 0;
const DDBAuthTokenDAO_1 = require("./DDBAuthTokenDAO");
const DDBFeedDAO_1 = require("./DDBFeedDAO");
const DDBFollowsDAO_1 = require("./DDBFollowsDAO");
const DDBStoryDAO_1 = require("./DDBStoryDAO");
const DDBUsersDAO_1 = require("./DDBUsersDAO");
const S3ImageDAO_1 = require("./S3ImageDAO");
class DDBDAOFactory {
    getAuthTokensDAO() {
        return new DDBAuthTokenDAO_1.DDBAuthTokenDAO();
    }
    getFeedDAO() {
        return new DDBFeedDAO_1.DDBFeedDAO();
    }
    getFollowsDAO() {
        return new DDBFollowsDAO_1.DDBFollowsDAO();
    }
    getStoryDAO() {
        return new DDBStoryDAO_1.DDBStoryDAO();
    }
    getUsersDAO() {
        return new DDBUsersDAO_1.DDBUsersDAO();
    }
    getImageDAO() {
        return new S3ImageDAO_1.S3ImageDAO();
    }
}
exports.DDBDAOFactory = DDBDAOFactory;
