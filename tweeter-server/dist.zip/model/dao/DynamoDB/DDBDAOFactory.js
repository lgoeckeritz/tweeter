"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DDBDAOFactory = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const DDBAuthTokenDAO_1 = require("./DDBAuthTokenDAO");
const DDBFeedDAO_1 = require("./DDBFeedDAO");
const DDBFollowsDAO_1 = require("./DDBFollowsDAO");
const DDBStoryDAO_1 = require("./DDBStoryDAO");
const DDBUsersDAO_1 = require("./DDBUsersDAO");
const S3ImageDAO_1 = require("./S3ImageDAO");
class DDBDAOFactory {
    constructor() {
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient());
    }
    getAuthTokensDAO() {
        return new DDBAuthTokenDAO_1.DDBAuthTokenDAO(this.client);
    }
    getFeedDAO() {
        return new DDBFeedDAO_1.DDBFeedDAO(this.client);
    }
    getFollowsDAO() {
        return new DDBFollowsDAO_1.DDBFollowsDAO(this.client);
    }
    getStoryDAO() {
        return new DDBStoryDAO_1.DDBStoryDAO(this.client);
    }
    getUsersDAO() {
        return new DDBUsersDAO_1.DDBUsersDAO(this.client);
    }
    getImageDAO() {
        return new S3ImageDAO_1.S3ImageDAO();
    }
}
exports.DDBDAOFactory = DDBDAOFactory;
