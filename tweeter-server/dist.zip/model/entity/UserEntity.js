"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserEntity = void 0;
const Entity_1 = require("./Entity");
class UserEntity extends Entity_1.Entity {
    constructor(firstName, lastName, alias, imageUrl, password, numFollowers, numFollowees) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.alias = alias;
        this.imageUrl = imageUrl;
        this.password = password;
        this.numFollowers = numFollowers;
        this.numFollowees = numFollowees;
    }
}
exports.UserEntity = UserEntity;
