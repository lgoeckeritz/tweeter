"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusEntity = void 0;
const Entity_1 = require("./Entity");
class StatusEntity extends Entity_1.Entity {
    constructor(handle, time_stamp, statusJson) {
        super();
        this.handle = handle;
        this.time_stamp = time_stamp;
        this.statusJson = statusJson;
    }
}
exports.StatusEntity = StatusEntity;
