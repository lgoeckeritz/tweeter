"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthTokenEntity = void 0;
const Entity_1 = require("./Entity");
class AuthTokenEntity extends Entity_1.Entity {
    constructor(token, timestamp, userHandle) {
        super();
        this.token = token;
        this.time_stamp = timestamp;
        this.userHandle = userHandle;
    }
}
exports.AuthTokenEntity = AuthTokenEntity;
