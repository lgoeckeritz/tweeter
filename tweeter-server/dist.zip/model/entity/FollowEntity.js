"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowEntity = void 0;
const Entity_1 = require("./Entity");
//TODO: consider removing the followername and followeename as they haven't been used yet
class FollowEntity extends Entity_1.Entity {
    constructor(followerHandle, followerName, followeeHandle, followeeName) {
        super();
        this.followerHandle = followerHandle;
        this.followerName = followerName;
        this.followeeHandle = followeeHandle;
        this.followeeName = followeeName;
    }
    toString() {
        return ("Follow{" +
            "follower handle='" +
            this.followerHandle +
            "'" +
            ", follower name='" +
            this.followerName +
            "'" +
            ", followee handle='" +
            this.followeeHandle +
            "'" +
            ", followee name='" +
            this.followeeName +
            "'}");
    }
}
exports.FollowEntity = FollowEntity;
