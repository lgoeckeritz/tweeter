"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Service = void 0;
class Service {
    constructor(daoFactory) {
        this.authTokenDAO = daoFactory.getAuthTokensDAO();
        this.storyDAO = daoFactory.getStoryDAO();
        this.feedDAO = daoFactory.getFeedDAO();
        this.usersDAO = daoFactory.getUsersDAO();
        this.followsDAO = daoFactory.getFollowsDAO();
        this.imageDAO = daoFactory.getImageDAO();
    }
    verfiyRequestData(parameters) {
        parameters.forEach((element) => {
            if (element === null || element === undefined) {
                throw new Error("[Bad Request] part or all of the request is null");
            }
        });
    }
    authenticate(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const authenticated = yield this.authTokenDAO.authenticate(token);
            if (authenticated === false) {
                throw new Error("[Forbidden Error] authtoken either doesn't exist or is timed out");
            }
        });
    }
    verifyReturn(entity) {
        if (entity == undefined || entity == null) {
            throw new Error("[Server Error] could not find entity in database");
        }
    }
}
exports.Service = Service;
