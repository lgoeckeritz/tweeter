"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const FollowEntity_1 = require("../entity/FollowEntity");
const Service_1 = require("./Service");
class FollowService extends Service_1.Service {
    constructor(daoFactory) {
        super(daoFactory);
    }
    loadMoreFollowers(authToken, user, pageSize, lastItem) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, user, pageSize]);
            this.authenticate(authToken.token);
            const pageOfFollowers = yield this.followsDAO.getPageOfFollowers(user.alias, pageSize, lastItem === null || lastItem === void 0 ? void 0 : lastItem.alias);
            // converting to array of user's followers
            const followers = [];
            for (let i = 0; i < pageOfFollowers.values.length; i++) {
                const followerHandle = pageOfFollowers.values[i].followerHandle;
                const userEntity = yield this.usersDAO.getUser(followerHandle);
                if (userEntity !== undefined) {
                    const follower = new tweeter_shared_1.User(userEntity.firstName, userEntity.lastName, userEntity.alias, userEntity.imageUrl);
                    followers.push(follower);
                }
            }
            return [followers, pageOfFollowers.hasMorePages];
        });
    }
    loadMoreFollowees(authToken, user, pageSize, lastItem) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, user, pageSize]);
            this.authenticate(authToken.token);
            const pageOfFollowees = yield this.followsDAO.getPageOfFollowees(user.alias, pageSize, lastItem === null || lastItem === void 0 ? void 0 : lastItem.alias);
            // converting to array of user's followees
            const followees = [];
            for (let i = 0; i < pageOfFollowees.values.length; i++) {
                const followeeHandle = pageOfFollowees.values[i].followeeHandle;
                const userEntity = yield this.usersDAO.getUser(followeeHandle);
                if (userEntity !== undefined) {
                    const followee = new tweeter_shared_1.User(userEntity.firstName, userEntity.lastName, userEntity.alias, userEntity.imageUrl);
                    followees.push(followee);
                }
            }
            return [followees, pageOfFollowees.hasMorePages];
        });
    }
    getIsFollowerStatus(authToken, user, selectedUser) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, user, selectedUser]);
            this.authenticate(authToken.token);
            const follow = new FollowEntity_1.FollowEntity(user.alias, user.firstName, selectedUser.alias, selectedUser.firstName);
            const result = yield this.followsDAO.getFollow(follow);
            if (result !== undefined) {
                return true;
            }
            else {
                return false;
            }
        });
    }
    getFolloweesCount(authToken, user) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, user]);
            this.authenticate(authToken.token);
            const userEntity = yield this.usersDAO.getUser(user.alias);
            this.verifyReturn(userEntity);
            return userEntity.numFollowees;
        });
    }
    getFollowersCount(authToken, user) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, user]);
            this.authenticate(authToken.token);
            const userEntity = yield this.usersDAO.getUser(user.alias);
            this.verifyReturn(userEntity);
            return userEntity.numFollowers;
        });
    }
    follow(authToken, userToFollow) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, userToFollow]);
            this.authenticate(authToken.token);
            const userHandle = yield this.authTokenDAO.getAuthTokenHandle(authToken.token);
            const userToFollowEntity = yield this.usersDAO.getUser(userToFollow.alias);
            const userEntity = yield this.usersDAO.getUser(userHandle);
            if (userEntity === undefined || userToFollowEntity == undefined) {
                throw new Error("[Server Error] couldn't find user");
            }
            yield this.followsDAO.putFollow(new FollowEntity_1.FollowEntity(userEntity.alias, userEntity.firstName, userToFollow.alias, userToFollow.firstName));
            //need to increment followers and following on this user and the
            //user that has just been followed
            yield this.usersDAO.updateNumFollowing(userEntity.alias, 1);
            yield this.usersDAO.updateNumFollowers(userToFollow.alias, 1);
            //this should return the numfollowers and followees of the userToFollow instead
            return [
                userToFollowEntity.numFollowers,
                userToFollowEntity.numFollowees,
            ];
        });
    }
    unfollow(authToken, userToUnfollow) {
        return __awaiter(this, void 0, void 0, function* () {
            this.verfiyRequestData([authToken, userToUnfollow]);
            this.authenticate(authToken.token);
            const userHandle = yield this.authTokenDAO.getAuthTokenHandle(authToken.token);
            const userEntity = yield this.usersDAO.getUser(userHandle);
            const userToUnFollowEntity = yield this.usersDAO.getUser(userToUnfollow.alias);
            if (userEntity === undefined || userToUnFollowEntity === undefined) {
                throw new Error("[Server Error] couldn't find user");
            }
            yield this.followsDAO.deleteFollow(new FollowEntity_1.FollowEntity(userEntity.alias, userEntity.firstName, userToUnfollow.alias, userToUnfollow.firstName));
            //need to decrement followers and following on this user and the
            //user that has just been unfollowed
            yield this.usersDAO.updateNumFollowing(userEntity.alias, -1);
            yield this.usersDAO.updateNumFollowers(userToUnfollow.alias, -1);
            //this should return the numfollowers and followees of the userToFollow instead
            return [
                userToUnFollowEntity.numFollowers,
                userToUnFollowEntity.numFollowees,
            ];
        });
    }
}
exports.FollowService = FollowService;
