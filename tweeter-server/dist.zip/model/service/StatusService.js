"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const StatusEntity_1 = require("../entity/StatusEntity");
class StatusService {
    constructor(daoFactory) {
        this.authTokenDAO = daoFactory.getAuthTokensDAO();
        this.storyDAO = daoFactory.getStoryDAO();
        this.feedDAO = daoFactory.getFeedDAO();
        this.usersDAO = daoFactory.getUsersDAO();
        this.followsDAO = daoFactory.getFollowsDAO();
    }
    loadMoreFeedItems(authToken, user, pageSize, lastItem) {
        return __awaiter(this, void 0, void 0, function* () {
            //checking to make sure request is good
            if (user === null || authToken === null || pageSize === null) {
                throw new Error("[Bad Request] part or all of the request is null");
            }
            const authenticated = yield this.authTokenDAO.authenticate(authToken.token);
            if (authenticated) {
                const feedPage = yield this.feedDAO.getFeed(user, pageSize, lastItem);
                const statusArr = [];
                feedPage.values.forEach((statusEntity) => {
                    try {
                        const status = tweeter_shared_1.Status.fromJson(statusEntity.statusJson);
                        if (status !== null) {
                            statusArr.push(status);
                        }
                    }
                    catch (error) {
                        console.log("Found null status. Error: " + error);
                    }
                });
                return [statusArr, feedPage.hasMorePages];
            }
            else {
                throw new Error("[Forbidden Error] authtoken either doesn't exist or is timed out");
            }
        });
    }
    loadMoreStoryItems(authToken, user, pageSize, lastItem) {
        return __awaiter(this, void 0, void 0, function* () {
            //checking to make sure request is good
            if (user === null || authToken === null || pageSize === null) {
                throw new Error("[Bad Request] part or all of the request is null");
            }
            const authenticated = yield this.authTokenDAO.authenticate(authToken.token);
            if (authenticated) {
                const storyPage = yield this.storyDAO.getStory(user, pageSize, lastItem);
                const statusArr = [];
                storyPage.values.forEach((statusEntity) => {
                    const status = tweeter_shared_1.Status.fromJson(statusEntity.statusJson);
                    if (status !== null) {
                        statusArr.push(status);
                    }
                });
                return [statusArr, storyPage.hasMorePages];
            }
            else {
                throw new Error("[Forbidden Error] authtoken either doesn't exist or is timed out");
            }
        });
    }
    postStatus(authToken, newStatus) {
        return __awaiter(this, void 0, void 0, function* () {
            //checking to make sure request is good
            if (authToken === null || newStatus === null) {
                throw new Error("[Bad Request] part or all of the request is null");
            }
            const authenticated = yield this.authTokenDAO.authenticate(authToken.token);
            if (authenticated) {
                //getting the user's handle
                const userHandle = yield this.authTokenDAO.getAuthTokenHandle(authToken.token);
                const newStatusEntity = new StatusEntity_1.StatusEntity(userHandle, Date.now(), newStatus.toJson());
                yield this.storyDAO.recordStory(newStatusEntity);
                //pushing the status to everyone that follows this user
                //getting the user to know how many followers there are
                const userEntity = yield this.usersDAO.getUser(userHandle);
                if (userEntity !== undefined) {
                    const numFollowers = userEntity.numFollowers;
                    //getting list of all followers
                    const followerPage = yield this.followsDAO.getPageOfFollowers(userHandle, numFollowers, undefined);
                    //adding the status to each of the followers of the user
                    followerPage.values.forEach((follow) => {
                        this.feedDAO.addStatus(new StatusEntity_1.StatusEntity(follow.followeeHandle, Date.now(), newStatus.toJson()));
                    });
                }
            }
            else {
                throw new Error("[Forbidden Error] authtoken either doesn't exist or is timed out");
            }
        });
    }
}
exports.StatusService = StatusService;
